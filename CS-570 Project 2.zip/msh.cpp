//Ayoub Rammo, Raegeorge Decastro
//class account username SSH: 
//REDIDs : 
//CS-570, Summer 2021  
//Assignment  #2 
//msh.cpp
#include<stdio.h>
#include<string.h>
#include<stdlib.h>
#include<unistd.h>
#include<sys/types.h>
#include<sys/wait.h>
#include <ostream>
#include <iostream>
#include <string>
#include <cstring>



#define MAX_COMANDS 1000 
#define MAX_ARGS 100 
#define red 1
#define green 0

// Clearing the shell using escape sequences
#define clear() printf("\033[H\033[J")


using namespace std;



//define methods
void execute_piped_args(char** parsed, char** parsedpipe);
void start_shell();
int get_command(char* str);
void process_args(char** parsed);
void execute_piped_args(char** parsed, char** parsedpipe);
int default_commands(char** parsed);
int process_pipe(char* str, char** piped_str);
void process_spacing(char* str, char** parsed);
int process_string(char* str, char** parsed, char** parsedpipe);


int main()
{
	char input_string[MAX_COMANDS], *parsedArgs[MAX_ARGS];
	char* parsedArgsPiped[MAX_ARGS];


	int exec_counter_flag = 0;


	start_shell();

	while (1) {
		
		// get commands from user
		if (get_command(input_string)){
			continue;
		}

		// process commands
		exec_counter_flag = process_string(input_string,parsedArgs, parsedArgsPiped);
		
		// execute
		if (exec_counter_flag == 1){
			process_args(parsedArgs);
		}

		if (exec_counter_flag == 2){
			execute_piped_args(parsedArgs, parsedArgsPiped);
		}
	}
	return 0;
}



// initialise my shell
void start_shell()
{
	clear();
	
	std::cout << "\n cssc4209 \n" << std::endl;
	
	sleep(1);
	
}

// get input from std in

int get_command(char* str)
{
	const char* buf;

	std::string input;

	std::cout<<"\n cssc4209 % ";
	std::getline(std::cin, input);
	
	// convert string to char array
	buf = input.c_str();


	if (strlen(buf) != 0) {
		
		strcpy(str, buf);
		return 0;
	} else {
		return 1;
	}
}



// functions are executed here
void process_args(char** parsed)
{
	// fork a child
	pid_t pid = fork();

	if (pid == -1) {
		std::cout << "\n Failed forking child.. "<<std::endl;
		return;
	} else if (pid == 0) {
		if (execvp(parsed[0], parsed) < 0) {

			std::cout <<"\n  Could not execute command..  "<<std::endl;
		}

		exit(0);
	} else {
		// waiting for child to terminate
		wait(NULL);
		return;
	}
}

// Function where the piped system commands is executed
void execute_piped_args(char** parsed, char** parsedpipe)
{
	
	int pipefd[2];
	pid_t proc_1, proc_2;

	if (pipe(pipefd) < 0) {
		std::cout << "\n Pipe could not be initialized "<<std::endl;
		return;
	}

	proc_1 = fork();
	if (proc_1 < 0) {
		std::cout << "\n Could not fork "<<std::endl;
		return;
	}

	if (proc_1 == 0) {
		
		close(pipefd[0]);

		dup2(pipefd[1], STDOUT_FILENO);

		close(pipefd[1]);

		if (execvp(parsed[0], parsed) < 0) {
			std::cout << "\n Could not execute command 1.."<<std::endl;
			exit(0);
		}


	} else {
		// Parent executing
		proc_2 = fork();

		if (proc_2 < 0) {
			printf("\n Could not fork");
			return;
		}

		// Child 2 executing..
		// It only needs to read at the read end
		if (proc_2 == 0) {
			close(pipefd[1]);
			dup2(pipefd[0], STDIN_FILENO);
			close(pipefd[0]);
			if (execvp(parsedpipe[0], parsedpipe) < 0) {
				std::cout << "\nCould not execute command 2.."<<std::endl;
				exit(0);
			}
		} else {
			
			wait(NULL);
			wait(NULL);
		}
	}
}




int default_commands(char** parsed)
{



	int num_dft_commands = 2, loop_counter, arg_counter = 0;
	char* command_array[num_dft_commands];
	

	command_array[0] = "exit";
	command_array[1] = "cd";
	
	for (loop_counter = 0; loop_counter < num_dft_commands; loop_counter++) {
		if (strcmp(parsed[0], command_array[loop_counter]) == 0) {
			arg_counter = loop_counter + 1;
			break;
		}
	}

	switch (arg_counter) {


	case 1:
		std::cout << "\n exiting \n" << std::endl;
		exit(0);
	case 2:
		chdir(parsed[1]);
		return 1;
	default:
		break;
	}

	return 0;
}

// get pipes
int process_pipe(char* str, char** piped_str)
{
	int loop_counter;
	for (loop_counter = 0; loop_counter < 2; loop_counter++) {

		piped_str[loop_counter] = strsep(&str, "|");

		if (piped_str[loop_counter] == NULL){
			break;
		}
	}

	if (piped_str[1] == NULL)
		return 0; 
	else {
		return 1;
	}
}

// function for parsing command words
void process_spacing(char* str, char** parsed)
{
	int loop_counter;

	for (loop_counter = 0; loop_counter < MAX_ARGS; loop_counter++) {
		parsed[loop_counter] = strsep(&str, " ");

		if (parsed[loop_counter] == NULL){
			break;
		}
		if (strlen(parsed[loop_counter]) == 0){
			loop_counter--;
		}
	}
}

int process_string(char* str, char** parsed, char** parsedpipe)
{

	char* piped_str[2];
	int piped = 0;

	piped = process_pipe(str, piped_str);

	if (piped) {
		process_spacing(piped_str[0], parsed);
		process_spacing(piped_str[1], parsedpipe);

	} else {

		process_spacing(str, parsed);
	}

	if (default_commands(parsed))
		return 0;
	else
		return 1 + piped;
}


